/// <reference types="blockbench-types" />
